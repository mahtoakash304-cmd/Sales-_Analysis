import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
random.seed(42)
np.random.seed(42)

# ── PROJECT 1: Retail Sales ────────────────────────────────────────────────────
regions    = ['North','South','East','West']
categories = ['Electronics','Clothing','FMCG','Home & Kitchen','Sports']
products = {
    'Electronics':    [('Bluetooth Speaker',1200),('Earphones',800),('Smart Watch',3500),('Power Bank',999),('USB Hub',450)],
    'Clothing':       [('Winter Jacket',2500),('Kurta Set',850),('Jeans',1200),('T-Shirt Pack',650),('Saree',1800)],
    'FMCG':           [('Shampoo Pack',350),('Face Wash',280),('Body Lotion',420),('Toothpaste Set',180),('Hair Oil',320)],
    'Home & Kitchen': [('Pressure Cooker',1800),('Non-stick Pan',950),('Water Bottle',350),('Mixer Grinder',2200),('Dinner Set',1400)],
    'Sports':         [('Yoga Mat',699),('Dumbbell Set',1500),('Cricket Bat',1200),('Badminton Racket',850),('Jump Rope',250)],
}
salespersons = ['Rahul Sharma','Priya Singh','Amit Verma','Sneha Roy','Vikram Das','Meera Joshi','Arjun Nair']

rows = []
start = datetime(2024,1,1)
for i in range(800):
    date = start + timedelta(days=random.randint(0,364))
    region = random.choices(regions, weights=[32,28,20,20])[0]
    cat = random.choices(categories, weights=[30,25,20,15,10])[0]
    prod, price = random.choice(products[cat])
    units = random.randint(1,50)
    discount = random.choice([0,5,8,10,12,15,20])
    total = units * price
    net = round(total * (1 - discount/100), 2)
    rows.append([f'ORD-{i+1:04d}', date.strftime('%Y-%m-%d'), region, cat, prod,
                 units, price, total, discount, net, random.choice(salespersons)])

df1 = pd.DataFrame(rows, columns=['Order_ID','Date','Region','Product_Category',
                                   'Product_Name','Units_Sold','Unit_Price',
                                   'Total_Revenue','Discount_Pct','Net_Revenue','Salesperson'])
df1.to_csv('/home/claude/portfolio/project1_sales/retail_sales_data.csv', index=False)
print(f'Project 1: {len(df1)} rows')

# ── PROJECT 2: Customer Data ───────────────────────────────────────────────────
first = ['Anjali','Rohit','Priya','Vikram','Meera','Arjun','Sneha','Rahul','Pooja','Amit',
         'Sunita','Deepak','Kavya','Sanjay','Ritu','Nikhil','Divya','Manish','Swati','Karan']
last  = ['Mehta','Gupta','Nair','Shah','Joshi','Kumar','Sharma','Singh','Verma','Roy',
         'Patel','Yadav','Reddy','Iyer','Pillai','Mishra','Agarwal','Choudhary','Saxena','Bose']
cities = ['Mumbai','Delhi','Bangalore','Hyderabad','Chennai','Pune','Ahmedabad','Kolkata','Jaipur','Lucknow']

rows2 = []
for i in range(500):
    name = f'{random.choice(first)} {random.choice(last)}'
    age  = random.randint(18,65)
    gender = random.choice(['Male','Female','Female'])
    city = random.choices(cities, weights=[20,18,15,12,10,9,6,5,3,2])[0]
    orders = random.randint(1,30)
    spent  = round(orders * random.uniform(800,4500), 0)
    days_ago = random.randint(5,400)
    last_date = (datetime(2024,12,31) - timedelta(days=days_ago)).strftime('%Y-%m-%d')
    reg_date  = (datetime(2024,12,31) - timedelta(days=random.randint(days_ago,1000))).strftime('%Y-%m-%d')
    rows2.append([f'CUST-{i+1:04d}', name, age, gender, city, orders, spent, last_date, reg_date])

df2 = pd.DataFrame(rows2, columns=['Customer_ID','Name','Age','Gender','City',
                                    'Total_Orders','Total_Spent','Last_Purchase_Date','Customer_Since'])
df2.to_csv('/home/claude/portfolio/project2_customers/customer_data.csv', index=False)
print(f'Project 2: {len(df2)} rows')

# ── PROJECT 3: E-Commerce Orders ──────────────────────────────────────────────
states  = ['Maharashtra','Delhi','Karnataka','Tamil Nadu','Gujarat','Rajasthan',
           'Bihar','Uttar Pradesh','West Bengal','Madhya Pradesh']
s_weights = [18,15,12,10,9,8,7,8,7,6]
cats    = ['Fashion','Electronics','Beauty','Home & Kitchen','Sports','Books','FMCG']
reasons = ['Wrong Size','Wrong Product','Quality Issue','Late Delivery','Changed Mind','Damaged']
pmodes  = ['UPI','COD','Credit Card','Debit Card']

rows3 = []
for i in range(1000):
    odate = datetime(2024,1,1) + timedelta(days=random.randint(0,364))
    cat   = random.choices(cats, weights=[28,22,15,12,10,8,5])[0]
    state = random.choices(states, weights=s_weights)[0]
    amount= round(random.uniform(200,8000), 0)
    exp_days = random.randint(4,8)
    exp_del   = odate + timedelta(days=exp_days)
    # Bihar, UP, MP get more delays
    if state in ['Bihar','Uttar Pradesh','Madhya Pradesh']:
        delay = random.choices([-1,0,1,2,3,5,8], weights=[5,10,20,20,20,15,10])[0]
    else:
        delay = random.choices([-2,-1,0,1,2,3], weights=[10,20,35,15,12,8])[0]
    act_del = exp_del + timedelta(days=delay)
    if cat == 'Fashion':
        status = random.choices(['On-Time','Late','Returned'], weights=[55,25,20])[0]
    elif delay > 0:
        status = 'Late'
    else:
        status = random.choices(['On-Time','Returned'], weights=[92,8])[0]
    reason = random.choice(reasons) if status == 'Returned' else 'NA'
    rows3.append([f'ECO-{i+1:05d}', odate.strftime('%Y-%m-%d'), f'CUST-{random.randint(1,500):04d}',
                  cat, amount, state, exp_del.strftime('%Y-%m-%d'), act_del.strftime('%Y-%m-%d'),
                  status, reason, random.choices(pmodes, weights=[40,30,18,12])[0]])

df3 = pd.DataFrame(rows3, columns=['Order_ID','Order_Date','Customer_ID','Category','Order_Amount',
                                    'State','Expected_Delivery','Actual_Delivery','Delivery_Status',
                                    'Return_Reason','Payment_Mode'])
df3.to_csv('/home/claude/portfolio/project3_ecommerce/ecommerce_orders.csv', index=False)
print(f'Project 3: {len(df3)} rows')

# ── PROJECT 4: Marketing Campaigns ────────────────────────────────────────────
campaign_names = {
    'Email':      ['New Year Email Blast','Holi Sale Newsletter','Independence Day Offer',
                   'Diwali Email Series','End of Year Campaign'],
    'Google Ads': ['Google Search Ads Q1','Shopping Ads Summer','Google Display Q3',
                   'Diwali Google Ads','Year-End Search'],
    'Instagram':  ['Reels Promo Jan','Instagram Stories Q2','IG Carousel Q3',
                   'Diwali Reels','New Year Stories'],
    'WhatsApp':   ['WhatsApp Broadcast Jan','WhatsApp Flash Sale','Diwali WhatsApp',
                   'Festive Offers Blast','Year-End WhatsApp'],
}

rows4 = []
idx = 1
for channel, names in campaign_names.items():
    for name in names:
        month = random.randint(1,12)
        sdate = datetime(2024, month, random.randint(1,15))
        dur   = random.randint(5,30)
        edate = sdate + timedelta(days=dur)
        if channel == 'WhatsApp':
            budget = random.randint(3000,8000)
            impr   = random.randint(10000,25000)
            ctr    = random.uniform(12,18)
        elif channel == 'Email':
            budget = random.randint(15000,35000)
            impr   = random.randint(80000,200000)
            ctr    = random.uniform(2.5,4.5)
        elif channel == 'Instagram':
            budget = random.randint(25000,60000)
            impr   = random.randint(300000,1000000)
            ctr    = random.uniform(0.8,2.0)
        else:  # Google
            budget = random.randint(50000,120000)
            impr   = random.randint(200000,500000)
            ctr    = random.uniform(2.0,4.0)
        clicks = int(impr * ctr / 100)
        conv_rate = random.uniform(2, 8) if channel in ['WhatsApp','Email'] else random.uniform(1,4)
        convs  = int(clicks * conv_rate / 100)
        aov    = random.uniform(600, 2500)
        revenue = round(convs * aov, 0)
        rows4.append([f'CAMP-{idx:03d}', name, channel, sdate.strftime('%Y-%m-%d'),
                      edate.strftime('%Y-%m-%d'), budget, impr, clicks, convs, revenue])
        idx += 1

df4 = pd.DataFrame(rows4, columns=['Campaign_ID','Campaign_Name','Channel','Start_Date',
                                    'End_Date','Budget_Spent','Impressions','Clicks',
                                    'Conversions','Revenue_Generated'])
df4['CTR_Pct']          = (df4.Clicks / df4.Impressions * 100).round(2)
df4['Conversion_Rate_Pct'] = (df4.Conversions / df4.Clicks * 100).round(2)
df4['ROI_Pct']          = ((df4.Revenue_Generated - df4.Budget_Spent) / df4.Budget_Spent * 100).round(1)
df4['Cost_Per_Conversion'] = (df4.Budget_Spent / df4.Conversions).round(0)
df4.to_csv('/home/claude/portfolio/project4_marketing/marketing_campaigns.csv', index=False)
print(f'Project 4: {len(df4)} rows')

# ── PROJECT 5: Products ────────────────────────────────────────────────────────
product_data = [
    ('Wireless Earbuds BoAt 131','Electronics','Audio','BoAt',1299,1999,1250,4.2,458,8.5,'In Stock'),
    ('Cotton Kurta Set','Fashion',"Women's Wear",'Fabindia',850,1200,890,4.6,1205,15.2,'In Stock'),
    ('Smart Water Bottle','Home & Kitchen','Drinkware','Milton',499,699,320,3.8,89,5.1,'Low Stock'),
    ('Yoga Mat Premium','Sports','Fitness','Boldfit',699,999,1560,4.5,782,3.2,'In Stock'),
    ('Bluetooth Speaker JBL','Electronics','Audio','JBL',3499,4999,445,4.7,2341,2.8,'In Stock'),
    ('Face Wash Neem','Beauty','Skincare','Himalaya',180,250,3200,4.1,892,4.3,'In Stock'),
    ('Non-stick Tawa','Home & Kitchen','Cookware','Prestige',650,950,760,4.3,341,6.1,'In Stock'),
    ('Cricket Bat Kashmir Willow','Sports','Cricket','SS',1200,1800,520,3.9,156,7.8,'In Stock'),
    ('Formal Shirt Pack','Fashion',"Men's Wear",'Allen Solly',1200,1699,680,4.0,423,9.2,'In Stock'),
    ('Power Bank 20000mAh','Electronics','Accessories','Mi',999,1499,2100,4.4,1876,3.5,'In Stock'),
    ('Hair Dryer Professional','Beauty','Hair Care','Philips',1800,2500,410,4.2,567,5.9,'In Stock'),
    ('Dinner Set Ceramic','Home & Kitchen','Dining','Cello',1400,2000,290,3.7,78,11.4,'Low Stock'),
    ('Running Shoes','Sports','Footwear','Nike',3499,4999,890,4.6,1230,4.1,'In Stock'),
    ('Saree Banarasi','Fashion',"Women's Wear",'Fabindia',2500,3500,340,4.8,892,18.3,'In Stock'),
    ('Smart Watch Boat Storm','Electronics','Wearables','BoAt',2499,3499,1560,4.1,2103,6.7,'In Stock'),
    ('Pressure Cooker 5L','Home & Kitchen','Cookware','Hawkins',1800,2500,670,4.5,456,4.2,'In Stock'),
    ('Shampoo Anti-Dandruff','Beauty','Hair Care','Head & Shoulders',320,450,4500,3.9,654,3.8,'In Stock'),
    ('Dumbbell Set 10kg','Sports','Fitness','Kore',1500,2200,430,4.3,234,2.9,'In Stock'),
    ('Earphones Wired','Electronics','Audio','Boat',299,499,3200,3.6,1023,9.8,'In Stock'),
    ('Jeans Slim Fit','Fashion',"Men's Wear",'Levis',2000,2999,780,4.2,567,11.2,'In Stock'),
    ('Face Pack Multani','Beauty','Skincare','Biotique',150,220,5600,4.0,1234,2.1,'In Stock'),
    ('Coffee Maker','Home & Kitchen','Appliances','Philips',3500,5000,210,4.4,345,3.3,'In Stock'),
    ('Badminton Set','Sports','Badminton','Yonex',1800,2500,380,4.5,289,3.7,'In Stock'),
    ('Kurta Pajama Set','Fashion',"Men's Wear",'Manyavar',1800,2500,520,4.7,678,7.4,'In Stock'),
    ('USB-C Hub 7-in-1','Electronics','Accessories','Portronics',1200,1799,890,3.8,432,5.6,'In Stock'),
    ('Body Lotion SPF','Beauty','Skincare','Lotus',380,550,2800,4.1,789,3.9,'In Stock'),
    ('Mixer Grinder 750W','Home & Kitchen','Appliances','Butterfly',2200,3200,560,4.3,678,4.8,'In Stock'),
    ('Skipping Rope Digital','Sports','Fitness','Strauss',599,899,670,4.0,123,4.2,'Low Stock'),
    ('Laptop Stand Adjustable','Electronics','Accessories','Zebronics',899,1299,1230,4.2,567,3.1,'In Stock'),
    ('Ethnic Dress Set','Fashion',"Women's Wear",'Biba',1500,2200,620,4.5,892,14.6,'In Stock'),
]

rows5 = []
for i,(pn,cat,sub,brand,price,mrp,units,rating,reviews,ret_rate,stock) in enumerate(product_data):
    disc = round((mrp-price)/mrp*100, 1)
    revenue = price * units
    rows5.append([f'PROD-{i+1:03d}', pn, cat, sub, brand, price, mrp, disc,
                  units, revenue, rating, reviews, ret_rate, stock])

df5 = pd.DataFrame(rows5, columns=['Product_ID','Product_Name','Category','Sub_Category',
                                    'Brand','Price','MRP','Discount_Pct','Units_Sold',
                                    'Total_Revenue','Avg_Rating','Review_Count',
                                    'Return_Rate_Pct','Stock_Status'])
df5.to_csv('/home/claude/portfolio/project5_products/product_performance.csv', index=False)
print(f'Project 5: {len(df5)} rows')
print('\n✅ All 5 datasets created!')
