"""
PROJECT 4: Marketing Campaign Performance Analysis
By: Akash Kumar Mahto | Data Analyst Portfolio
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    'figure.facecolor': '#0A0F1C', 'axes.facecolor': '#111827',
    'axes.edgecolor': '#1E3A5F', 'text.color': '#E2E8F0',
    'axes.labelcolor': '#94A3B8', 'xtick.color': '#94A3B8',
    'ytick.color': '#94A3B8', 'grid.color': '#1E3A5F', 'grid.alpha': 0.5,
})
CHANNEL_COLORS = {'Email':'#00D4AA','Google Ads':'#4D96FF','Instagram':'#C084FC','WhatsApp':'#6BCB77'}

# ── Load & Clean ───────────────────────────────────────────────────────────────
df = pd.read_csv('marketing_campaigns.csv')

df['Start_Date'] = pd.to_datetime(df['Start_Date'])
df['End_Date']   = pd.to_datetime(df['End_Date'])
df = df[df['End_Date'] > df['Start_Date']]
df = df[df['Clicks'] <= df['Impressions']]
df = df[df['Conversions'] <= df['Clicks']]
df['Duration_Days'] = (df['End_Date'] - df['Start_Date']).dt.days

# Recalculate all KPIs
df['CTR_Pct']             = (df['Clicks'] / df['Impressions'] * 100).round(2)
df['Conversion_Rate_Pct'] = (df['Conversions'] / df['Clicks'] * 100).round(2)
df['ROI_Pct']             = ((df['Revenue_Generated'] - df['Budget_Spent']) / df['Budget_Spent'] * 100).round(1)
df['Cost_Per_Conversion'] = (df['Budget_Spent'] / df['Conversions']).round(0)
df['Revenue_Per_Click']   = (df['Revenue_Generated'] / df['Clicks']).round(1)
df.to_csv('marketing_clean.csv', index=False)

# ── Channel Analysis ───────────────────────────────────────────────────────────
channel = df.groupby('Channel').agg(
    Campaigns=('Campaign_ID','count'),
    Total_Budget=('Budget_Spent','sum'),
    Total_Revenue=('Revenue_Generated','sum'),
    Total_Impressions=('Impressions','sum'),
    Total_Clicks=('Clicks','sum'),
    Total_Conversions=('Conversions','sum'),
    Avg_CTR=('CTR_Pct','mean'),
    Avg_Conv_Rate=('Conversion_Rate_Pct','mean'),
    Avg_CPC=('Cost_Per_Conversion','mean'),
).reset_index()
channel['Overall_ROI_Pct'] = ((channel['Total_Revenue'] - channel['Total_Budget']) /
                               channel['Total_Budget'] * 100).round(1)
channel['Overall_CTR'] = (channel['Total_Clicks'] / channel['Total_Impressions'] * 100).round(2)
channel = channel.sort_values('Overall_ROI_Pct', ascending=False)

best_roi    = channel.iloc[0]
best_eff    = channel.sort_values('Avg_CPC').iloc[0]
total_rev   = df['Revenue_Generated'].sum()
total_bud   = df['Budget_Spent'].sum()
overall_roi = (total_rev - total_bud) / total_bud * 100

print("=" * 65)
print("   PROJECT 4: MARKETING CAMPAIGN PERFORMANCE ANALYSIS")
print("=" * 65)
print(f"\n  Total Campaigns    : {len(df)}")
print(f"  Total Budget Spent : INR {total_bud:>12,.0f}")
print(f"  Total Revenue      : INR {total_rev:>12,.0f}")
print(f"  Overall ROI        : {overall_roi:.1f}%")
print(f"  Best ROI Channel   : {best_roi['Channel']} ({best_roi['Overall_ROI_Pct']:.1f}% ROI)")
print(f"  Most Efficient     : {best_eff['Channel']} (INR {best_eff['Avg_CPC']:.0f}/conversion)")

print(f"\nChannel Performance Scorecard:")
print(f"{'Channel':<14} {'Budget':>10} {'Revenue':>11} {'ROI%':>7} {'CTR%':>6} {'Conv%':>6} {'CPC':>7}")
print("-" * 65)
for _, row in channel.iterrows():
    print(f"{row['Channel']:<14} INR {row['Total_Budget']:>7,.0f} INR {row['Total_Revenue']:>8,.0f}"
          f" {row['Overall_ROI_Pct']:>7.1f} {row['Overall_CTR']:>6.2f} {row['Avg_Conv_Rate']:>6.2f}"
          f" {row['Avg_CPC']:>7.0f}")

print(f"\nTop 5 Campaigns by ROI:")
top5 = df.nlargest(5,'ROI_Pct')[['Campaign_Name','Channel','Budget_Spent','Revenue_Generated','ROI_Pct']]
for _, r in top5.iterrows():
    print(f"  {r['Campaign_Name'][:28]:<28} | {r['Channel']:<12} | ROI: {r['ROI_Pct']:.1f}%")
print("=" * 65)

# ── Charts ─────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12))
fig.suptitle('PROJECT 4: Marketing Campaign Performance Dashboard\nAkash Kumar Mahto | Data Analyst Portfolio',
             fontsize=14, fontweight='bold', color='#C084FC', y=0.98)

ch_colors = [CHANNEL_COLORS.get(c,'#FF6B6B') for c in channel['Channel']]

# ROI by Channel
ax1 = fig.add_subplot(2, 3, 1)
bars1 = ax1.bar(channel['Channel'], channel['Overall_ROI_Pct'], color=ch_colors, alpha=0.9, width=0.5, zorder=3)
ax1.axhline(y=100, color='#FFD93D', linestyle='--', linewidth=1.5, label='Break-even (100%)')
ax1.set_title('ROI by Channel (%)', fontweight='bold')
ax1.set_ylabel('ROI (%)')
ax1.legend(fontsize=8)
ax1.grid(axis='y', zorder=0)
for bar, val in zip(bars1, channel['Overall_ROI_Pct']):
    ax1.text(bar.get_x()+bar.get_width()/2, bar.get_height()+10,
             f'{val:.0f}%', ha='center', fontsize=9, color='white', fontweight='bold')

# Budget vs Revenue Scatter
ax2 = fig.add_subplot(2, 3, 2)
for _, row in channel.iterrows():
    c = CHANNEL_COLORS.get(row['Channel'],'#FF6B6B')
    ax2.scatter(row['Total_Budget']/1000, row['Total_Revenue']/1000, s=200, color=c, zorder=5, alpha=0.9)
    ax2.annotate(row['Channel'], (row['Total_Budget']/1000, row['Total_Revenue']/1000),
                 textcoords='offset points', xytext=(8,4), fontsize=9, color=c)
# Break-even line
x_max = channel['Total_Budget'].max() / 1000 * 1.2
ax2.plot([0, x_max], [0, x_max], color='#475569', linestyle='--', linewidth=1, label='Break-even')
ax2.set_title('Budget vs Revenue by Channel (INR 000s)', fontweight='bold')
ax2.set_xlabel('Budget Spent (INR 000s)')
ax2.set_ylabel('Revenue Generated (INR 000s)')
ax2.legend(fontsize=8)
ax2.grid(zorder=0)

# CTR Comparison
ax3 = fig.add_subplot(2, 3, 3)
ax3.bar(channel['Channel'], channel['Overall_CTR'], color=ch_colors, alpha=0.9, width=0.5, zorder=3)
ax3.set_title('Click-Through Rate (CTR) by Channel (%)', fontweight='bold')
ax3.set_ylabel('CTR (%)')
ax3.grid(axis='y', zorder=0)

# Cost Per Conversion
ax4 = fig.add_subplot(2, 3, 4)
cpc_sorted = channel.sort_values('Avg_CPC')
bars4 = ax4.bar(cpc_sorted['Channel'], cpc_sorted['Avg_CPC'],
                color=[CHANNEL_COLORS.get(c,'#FF6B6B') for c in cpc_sorted['Channel']],
                alpha=0.9, width=0.5, zorder=3)
ax4.set_title('Cost Per Conversion by Channel (INR)', fontweight='bold')
ax4.set_ylabel('Cost Per Conversion (INR)')
ax4.grid(axis='y', zorder=0)
for bar in bars4:
    ax4.text(bar.get_x()+bar.get_width()/2, bar.get_height()+5,
             f'INR {bar.get_height():.0f}', ha='center', fontsize=9, color='white')

# Monthly Campaign Count by Channel
ax5 = fig.add_subplot(2, 3, 5)
df['Month'] = df['Start_Date'].dt.strftime('%b')
month_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
monthly_ch  = df.groupby(['Month','Channel'])['Revenue_Generated'].sum().unstack(fill_value=0)
monthly_ch  = monthly_ch.reindex([m for m in month_order if m in monthly_ch.index])
bottom = np.zeros(len(monthly_ch))
for ch_name in monthly_ch.columns:
    vals = monthly_ch[ch_name].values / 1000
    ax5.bar(monthly_ch.index, vals, bottom=bottom,
            color=CHANNEL_COLORS.get(ch_name,'#999'), alpha=0.85, label=ch_name)
    bottom += vals
ax5.set_title('Monthly Revenue by Channel (INR 000s)', fontweight='bold')
ax5.set_ylabel('Revenue (INR 000s)')
ax5.legend(fontsize=8, loc='upper left')
ax5.tick_params(axis='x', rotation=30)
ax5.grid(axis='y', zorder=0)

# Campaign ROI Distribution
ax6 = fig.add_subplot(2, 3, 6)
for ch_name in df['Channel'].unique():
    ch_data = df[df['Channel']==ch_name]['ROI_Pct']
    ax6.scatter([ch_name]*len(ch_data), ch_data, alpha=0.6, s=60,
                color=CHANNEL_COLORS.get(ch_name,'#999'), zorder=3)
ax6.axhline(y=100, color='#FFD93D', linestyle='--', linewidth=1.5, label='Break-even')
ax6.set_title('ROI Distribution per Campaign', fontweight='bold')
ax6.set_ylabel('ROI (%)')
ax6.legend(fontsize=8)
ax6.grid(axis='y', zorder=0)

plt.tight_layout(rect=[0,0,1,0.96])
plt.savefig('marketing_dashboard.png', dpi=150, bbox_inches='tight', facecolor='#0A0F1C', edgecolor='none')
plt.close()
print("\n✅ Chart saved: marketing_dashboard.png")

# ── Excel ──────────────────────────────────────────────────────────────────────
with pd.ExcelWriter('marketing_analysis_report.xlsx', engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Clean Data', index=False)
    channel.to_excel(writer, sheet_name='Channel Performance', index=False)
    df.nlargest(10,'ROI_Pct').to_excel(writer, sheet_name='Top Campaigns by ROI', index=False)
    df.nlargest(10,'Revenue_Generated').to_excel(writer, sheet_name='Top by Revenue', index=False)
print("✅ Excel saved: marketing_analysis_report.xlsx")
print("\n🎯 Project 4 Complete!")
