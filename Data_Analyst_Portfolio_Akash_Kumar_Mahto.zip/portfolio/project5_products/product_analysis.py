"""
PROJECT 5: Product Rating & Performance Analysis
By: Akash Kumar Mahto | Data Analyst Portfolio
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import MinMaxScaler

plt.rcParams.update({
    'figure.facecolor': '#0A0F1C', 'axes.facecolor': '#111827',
    'axes.edgecolor': '#1E3A5F', 'text.color': '#E2E8F0',
    'axes.labelcolor': '#94A3B8', 'xtick.color': '#94A3B8',
    'ytick.color': '#94A3B8', 'grid.color': '#1E3A5F', 'grid.alpha': 0.5,
})
COLORS = ['#6BCB77','#00D4AA','#4D96FF','#FFD93D','#C084FC','#FF6B6B','#FF9F43']

# ── Load & Clean ───────────────────────────────────────────────────────────────
df = pd.read_csv('product_performance.csv')

df = df[(df['Avg_Rating'] >= 1) & (df['Avg_Rating'] <= 5)]
df = df[df['MRP'] >= df['Price']]
df = df[df['Units_Sold'] >= 0]
df['Discount_Pct']   = ((df['MRP'] - df['Price']) / df['MRP'] * 100).round(1)
df['Total_Revenue']  = df['Price'] * df['Units_Sold']

def rate_cat(r):
    if r >= 4.5: return 'Excellent (4.5+)'
    elif r >= 4.0: return 'Good (4.0-4.4)'
    elif r >= 3.5: return 'Average (3.5-3.9)'
    else:          return 'Poor (<3.5)'

df['Rating_Category'] = df['Avg_Rating'].apply(rate_cat)

# Performance Score (Weighted)
scaler = MinMaxScaler()
df['Rev_Score'] = scaler.fit_transform(df[['Total_Revenue']]) * 50
df['Rat_Score'] = scaler.fit_transform(df[['Avg_Rating']]) * 30
df['Ret_Score'] = (1 - scaler.fit_transform(df[['Return_Rate_Pct']])) * 20
df['Performance_Score'] = (df['Rev_Score'] + df['Rat_Score'] + df['Ret_Score']).round(1)

df.to_csv('product_clean.csv', index=False)

# ── Analysis ───────────────────────────────────────────────────────────────────
category_perf = df.groupby('Category').agg(
    Products=('Product_ID','count'),
    Total_Revenue=('Total_Revenue','sum'),
    Avg_Rating=('Avg_Rating','mean'),
    Avg_Return_Rate=('Return_Rate_Pct','mean'),
    Avg_Discount=('Discount_Pct','mean'),
    Total_Units=('Units_Sold','sum')
).reset_index().sort_values('Total_Revenue', ascending=False)

brand_perf = df.groupby('Brand').agg(
    Revenue=('Total_Revenue','sum'),
    Avg_Rating=('Avg_Rating','mean'),
    Products=('Product_ID','count')
).sort_values('Revenue', ascending=False)

top10  = df.nlargest(10, 'Performance_Score')[['Product_Name','Category','Performance_Score','Avg_Rating','Total_Revenue','Return_Rate_Pct']]
worst5 = df.nsmallest(5, 'Performance_Score')[['Product_Name','Category','Performance_Score','Avg_Rating','Return_Rate_Pct']]

corr = df[['Price','Discount_Pct','Units_Sold','Avg_Rating','Return_Rate_Pct']].corr()

# Rating vs Sales groups
rating_groups = df.groupby('Rating_Category').agg(
    Avg_Sales=('Units_Sold','mean'), Count=('Product_ID','count')
)

print("=" * 62)
print("   PROJECT 5: PRODUCT RATING & PERFORMANCE ANALYSIS")
print("=" * 62)
print(f"\n  Total Products Analyzed : {len(df)}")
print(f"  Platform Avg Rating     : {df['Avg_Rating'].mean():.2f} / 5.0")
print(f"  Total Revenue           : INR {df['Total_Revenue'].sum():,.0f}")
print(f"  Avg Return Rate         : {df['Return_Rate_Pct'].mean():.1f}%")
print(f"\nTop 10 Products (by Performance Score):")
print(f"{'Product':<32} {'Cat':<16} {'Score':>6} {'Rating':>7} {'Rev':>10}")
print("-" * 75)
for _, r in top10.iterrows():
    print(f"{r['Product_Name'][:31]:<32} {r['Category']:<16} {r['Performance_Score']:>6.1f} {r['Avg_Rating']:>7.1f} INR {r['Total_Revenue']:>7,.0f}")

print(f"\nBottom 5 Products (Need Attention):")
for _, r in worst5.iterrows():
    print(f"  {r['Product_Name'][:30]:<30} Score:{r['Performance_Score']:>5.1f} | Rating:{r['Avg_Rating']:.1f} | Return:{r['Return_Rate_Pct']:.1f}%")

print(f"\nCategory Analysis:")
for _, r in category_perf.iterrows():
    print(f"  {r['Category']:<18}: INR {r['Total_Revenue']:>10,.0f} | Avg Rating: {r['Avg_Rating']:.2f} | Return Rate: {r['Avg_Return_Rate']:.1f}%")

print(f"\nCorrelation: Rating vs Units Sold = {corr.loc['Avg_Rating','Units_Sold']:.2f}")
print(f"Correlation: Discount vs Units Sold = {corr.loc['Discount_Pct','Units_Sold']:.2f}")
print("=" * 62)

# ── Charts ─────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12))
fig.suptitle('PROJECT 5: Product Performance Analysis Dashboard\nAkash Kumar Mahto | Data Analyst Portfolio',
             fontsize=14, fontweight='bold', color='#6BCB77', y=0.98)

# Revenue by Category
ax1 = fig.add_subplot(2, 3, 1)
bars1 = ax1.barh(category_perf['Category'][::-1], category_perf['Total_Revenue'][::-1]/1000,
                 color=COLORS[:len(category_perf)], alpha=0.85, height=0.6, zorder=3)
ax1.set_title('Revenue by Category (INR 000s)', fontweight='bold')
ax1.set_xlabel('Revenue (INR 000s)')
ax1.grid(axis='x', zorder=0)

# Rating Distribution
ax2 = fig.add_subplot(2, 3, 2)
ax2.hist(df['Avg_Rating'], bins=15, color='#FFD93D', alpha=0.85, edgecolor='#0A0F1C', zorder=3)
ax2.axvline(x=df['Avg_Rating'].mean(), color='#FF6B6B', linestyle='--',
            linewidth=2, label=f'Mean: {df["Avg_Rating"].mean():.2f}')
ax2.axvline(x=4.0, color='#00D4AA', linestyle='--', linewidth=1.5, label='4.0 Target')
ax2.set_title('Product Rating Distribution', fontweight='bold')
ax2.set_xlabel('Average Rating')
ax2.set_ylabel('Number of Products')
ax2.legend(fontsize=8)
ax2.grid(axis='y', zorder=0)

# Scatter: Rating vs Units Sold
ax3 = fig.add_subplot(2, 3, 3)
scatter = ax3.scatter(df['Avg_Rating'], df['Units_Sold'],
                      c=df['Total_Revenue']/1000, cmap='YlGn', s=80, alpha=0.75, zorder=3,
                      edgecolors='#1E3A5F', linewidths=0.5)
plt.colorbar(scatter, ax=ax3, label='Revenue (INR 000s)')
ax3.axvline(x=4.0, color='#FF6B6B', linestyle='--', linewidth=1, label='4.0 line')
ax3.set_title('Rating vs Units Sold (Color = Revenue)', fontweight='bold')
ax3.set_xlabel('Average Rating')
ax3.set_ylabel('Units Sold')
ax3.legend(fontsize=8)
ax3.grid(zorder=0)
# Add correlation annotation
r = corr.loc['Avg_Rating','Units_Sold']
ax3.annotate(f'Correlation r = {r:.2f}', xy=(0.05, 0.92), xycoords='axes fraction',
             color='#00D4AA', fontsize=10, fontweight='bold')

# Avg Rating by Category
ax4 = fig.add_subplot(2, 3, 4)
cat_rating = category_perf.sort_values('Avg_Rating', ascending=False)
bars4 = ax4.bar(cat_rating['Category'], cat_rating['Avg_Rating'],
                color=COLORS[:len(cat_rating)], alpha=0.85, width=0.6, zorder=3)
ax4.axhline(y=4.0, color='#FF6B6B', linestyle='--', linewidth=1.5, label='4.0 Target')
ax4.set_title('Avg Rating by Category', fontweight='bold')
ax4.set_ylabel('Average Rating')
ax4.set_ylim(0, 5.5)
ax4.legend(fontsize=8)
ax4.tick_params(axis='x', rotation=30)
ax4.grid(axis='y', zorder=0)
for bar, val in zip(bars4, cat_rating['Avg_Rating']):
    ax4.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.05,
             f'{val:.2f}', ha='center', fontsize=9, color='white')

# Top 10 Performance Score
ax5 = fig.add_subplot(2, 3, 5)
ax5.barh(top10['Product_Name'].str[:18][::-1], top10['Performance_Score'][::-1],
         color='#6BCB77', alpha=0.85, height=0.6, zorder=3)
ax5.set_title('Top 10 Products: Performance Score', fontweight='bold')
ax5.set_xlabel('Performance Score (0-100)')
ax5.grid(axis='x', zorder=0)

# Return Rate by Category
ax6 = fig.add_subplot(2, 3, 6)
cat_ret = category_perf.sort_values('Avg_Return_Rate', ascending=False)
bars6 = ax6.bar(cat_ret['Category'], cat_ret['Avg_Return_Rate'],
                color='#FF6B6B', alpha=0.85, width=0.6, zorder=3)
ax6.axhline(y=df['Return_Rate_Pct'].mean(), color='#FFD93D', linestyle='--',
            linewidth=1.5, label=f'Avg {df["Return_Rate_Pct"].mean():.1f}%')
ax6.set_title('Return Rate by Category (%)', fontweight='bold')
ax6.set_ylabel('Return Rate (%)')
ax6.tick_params(axis='x', rotation=30)
ax6.legend(fontsize=8)
ax6.grid(axis='y', zorder=0)

plt.tight_layout(rect=[0,0,1,0.96])
plt.savefig('product_dashboard.png', dpi=150, bbox_inches='tight', facecolor='#0A0F1C', edgecolor='none')
plt.close()
print("\n✅ Chart saved: product_dashboard.png")

# ── Excel ──────────────────────────────────────────────────────────────────────
with pd.ExcelWriter('product_analysis_report.xlsx', engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Clean Data', index=False)
    category_perf.to_excel(writer, sheet_name='Category Analysis', index=False)
    brand_perf.reset_index().to_excel(writer, sheet_name='Brand Analysis', index=False)
    top10.to_excel(writer, sheet_name='Top 10 Products', index=False)
    worst5.to_excel(writer, sheet_name='Need Attention', index=False)
    corr.to_excel(writer, sheet_name='Correlation Matrix')
print("✅ Excel saved: product_analysis_report.xlsx")
print("\n🎯 Project 5 Complete!")
