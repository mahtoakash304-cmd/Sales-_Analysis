"""
PROJECT 1: Retail Store Monthly Sales Analysis
By: Akash Kumar Mahto | Data Analyst Portfolio
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# ── Style Setup ────────────────────────────────────────────────────────────────
plt.rcParams.update({
    'figure.facecolor': '#0A0F1C', 'axes.facecolor': '#111827',
    'axes.edgecolor': '#1E3A5F',   'text.color': '#E2E8F0',
    'axes.labelcolor': '#94A3B8',  'xtick.color': '#94A3B8',
    'ytick.color': '#94A3B8',      'grid.color': '#1E3A5F',
    'grid.alpha': 0.5,             'font.family': 'DejaVu Sans',
})
COLORS = ['#00D4AA','#4D96FF','#FF6B6B','#FFD93D','#C084FC','#6BCB77','#FF9F43']

# ── Load & Clean ───────────────────────────────────────────────────────────────
df = pd.read_csv('retail_sales_data.csv')

# Cleaning
df.drop_duplicates(inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Region'] = df['Region'].str.strip().str.title()
df['Product_Category'] = df['Product_Category'].str.strip()
df.dropna(subset=['Order_ID', 'Net_Revenue'], inplace=True)
df = df[df['Units_Sold'] > 0]
df = df[df['Net_Revenue'] > 0]

# Add time columns
df['Month']      = df['Date'].dt.month
df['Month_Name'] = df['Date'].dt.strftime('%b')
df['Quarter']    = 'Q' + df['Date'].dt.quarter.astype(str)
df['Year']       = df['Date'].dt.year

df_clean = df.copy()
df_clean.to_csv('retail_sales_clean.csv', index=False)

# ── Analysis ───────────────────────────────────────────────────────────────────
total_rev    = df['Net_Revenue'].sum()
total_orders = df['Order_ID'].count()
avg_order    = df['Net_Revenue'].mean()
total_units  = df['Units_Sold'].sum()

month_order  = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
monthly      = df.groupby('Month_Name')['Net_Revenue'].sum().reindex(month_order).fillna(0)
region_rev   = df.groupby('Region')['Net_Revenue'].sum().sort_values(ascending=False)
category_rev = df.groupby('Product_Category')['Net_Revenue'].sum().sort_values(ascending=False)
top5_prod    = df.groupby('Product_Name')['Net_Revenue'].sum().nlargest(5)
quarter_rev  = df.groupby('Quarter')['Net_Revenue'].sum()
salesperson  = df.groupby('Salesperson').agg(
    Revenue=('Net_Revenue','sum'), Orders=('Order_ID','count')).sort_values('Revenue',ascending=False)
region_orders = df.groupby('Region')['Order_ID'].count()
pivot = df.pivot_table(values='Net_Revenue', index='Region', columns='Product_Category', aggfunc='sum').fillna(0)

# ── Print Summary ──────────────────────────────────────────────────────────────
print("=" * 55)
print("   PROJECT 1: RETAIL SALES ANALYSIS - SUMMARY REPORT")
print("=" * 55)
print(f"  Total Revenue       : INR {total_rev:>12,.0f}")
print(f"  Total Orders        : {total_orders:>15,}")
print(f"  Total Units Sold    : {total_units:>15,}")
print(f"  Avg Order Value     : INR {avg_order:>12,.0f}")
print(f"  Best Month          : {monthly.idxmax()}")
print(f"  Top Region          : {region_rev.idxmax()} (INR {region_rev.max():,.0f})")
print(f"  Top Category        : {category_rev.idxmax()}")
print(f"  Top Salesperson     : {salesperson.index[0]}")
print("-" * 55)
print("\nRegion-wise Revenue:")
for r, v in region_rev.items():
    pct = v / total_rev * 100
    print(f"  {r:<10}: INR {v:>10,.0f}  ({pct:.1f}%)")
print("\nCategory-wise Revenue:")
for c, v in category_rev.items():
    pct = v / total_rev * 100
    print(f"  {c:<18}: INR {v:>10,.0f}  ({pct:.1f}%)")
print("\nTop 5 Products by Revenue:")
for i,(p,v) in enumerate(top5_prod.items(),1):
    print(f"  {i}. {p:<28}: INR {v:>8,.0f}")
print("\nQuarterly Revenue:")
for q, v in quarter_rev.items():
    pct = v / total_rev * 100
    print(f"  {q}: INR {v:>10,.0f}  ({pct:.1f}%)")
print("\nSalesperson Performance (Top 5):")
for sp_, row in salesperson.head(5).iterrows():
    print(f"  {sp_:<18}: INR {row['Revenue']:>10,.0f}  ({row['Orders']} orders)")
print("=" * 55)

# ── Dashboard Chart ────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12))
fig.suptitle('PROJECT 1: Retail Sales Analysis Dashboard\nAkash Kumar Mahto | Data Analyst Portfolio',
             fontsize=14, fontweight='bold', color='#00D4AA', y=0.98)

ax1 = fig.add_subplot(3, 3, (1, 2))
bars = ax1.bar(monthly.index, monthly.values / 1000, color=COLORS[0], alpha=0.85, width=0.6, zorder=3)
ax1.set_title('Monthly Revenue Trend (INR 000s)', fontweight='bold', pad=8)
ax1.set_ylabel('Revenue (INR 000s)')
ax1.grid(axis='y', zorder=0)
best_idx = monthly.values.argmax()
bars[best_idx].set_color('#FFD93D')
ax1.annotate(f'Peak\n{monthly.index[best_idx]}', xy=(best_idx, monthly.values[best_idx]/1000),
             xytext=(best_idx+0.5, monthly.values[best_idx]/1000 * 0.85),
             color='#FFD93D', fontsize=8, fontweight='bold',
             arrowprops=dict(arrowstyle='->', color='#FFD93D'))

ax2 = fig.add_subplot(3, 3, 3)
wedges, texts, autotexts = ax2.pie(region_rev.values, labels=region_rev.index,
    autopct='%1.1f%%', colors=COLORS[:len(region_rev)], pctdistance=0.75,
    wedgeprops=dict(width=0.6, edgecolor='#0A0F1C', linewidth=1.5))
for t in autotexts: t.set_fontsize(9); t.set_color('white')
ax2.set_title('Revenue by Region', fontweight='bold', pad=8)

ax3 = fig.add_subplot(3, 3, (4, 5))
h_bars = ax3.barh(category_rev.index[::-1], category_rev.values[::-1] / 1000,
                  color=COLORS[1], alpha=0.85, height=0.6, zorder=3)
ax3.set_title('Revenue by Product Category (INR 000s)', fontweight='bold', pad=8)
ax3.set_xlabel('Revenue (INR 000s)')
ax3.grid(axis='x', zorder=0)
for i, (bar, val) in enumerate(zip(h_bars, category_rev.values[::-1])):
    ax3.text(val/1000 + 5, bar.get_y() + bar.get_height()/2,
             f'INR {val/1000:.0f}K', va='center', fontsize=8, color='#94A3B8')

ax4 = fig.add_subplot(3, 3, 6)
ax4.bar(top5_prod.index, top5_prod.values / 1000, color=COLORS[2], alpha=0.85, width=0.6, zorder=3)
ax4.set_title('Top 5 Products by Revenue', fontweight='bold', pad=8)
ax4.set_ylabel('Revenue (INR 000s)')
ax4.set_xticks(range(len(top5_prod)))
ax4.set_xticklabels([x[:12] for x in top5_prod.index], rotation=30, ha='right', fontsize=8)
ax4.grid(axis='y', zorder=0)

ax5 = fig.add_subplot(3, 3, 7)
q_bars = ax5.bar(quarter_rev.index, quarter_rev.values / 1000,
                 color=[COLORS[0],COLORS[1],COLORS[3],COLORS[2]], alpha=0.9, width=0.5, zorder=3)
ax5.set_title('Quarterly Revenue (INR 000s)', fontweight='bold', pad=8)
ax5.set_ylabel('Revenue (INR 000s)')
ax5.grid(axis='y', zorder=0)
for bar in q_bars:
    ax5.text(bar.get_x()+bar.get_width()/2, bar.get_height()+2,
             f'{bar.get_height():.0f}K', ha='center', fontsize=8, color='white')

ax6 = fig.add_subplot(3, 3, (8, 9))
sp_top = salesperson.head(6)
ax6.barh(sp_top.index[::-1], sp_top['Revenue'][::-1] / 1000,
         color=COLORS[4], alpha=0.85, height=0.6, zorder=3)
ax6.set_title('Top 6 Salesperson Performance (INR 000s)', fontweight='bold', pad=8)
ax6.set_xlabel('Revenue (INR 000s)')
ax6.grid(axis='x', zorder=0)

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('sales_dashboard.png', dpi=150, bbox_inches='tight',
            facecolor='#0A0F1C', edgecolor='none')
plt.close()
print("\n✅ Chart saved: sales_dashboard.png")

# ── Excel Report ───────────────────────────────────────────────────────────────
with pd.ExcelWriter('sales_analysis_report.xlsx', engine='openpyxl') as writer:
    df_clean.to_excel(writer, sheet_name='Clean Data', index=False)
    monthly.reset_index().rename(columns={'Month_Name':'Month','Net_Revenue':'Revenue'}).to_excel(
        writer, sheet_name='Monthly Revenue', index=False)
    region_rev.reset_index().rename(columns={'Net_Revenue':'Revenue'}).to_excel(
        writer, sheet_name='Region Analysis', index=False)
    category_rev.reset_index().rename(columns={'Net_Revenue':'Revenue'}).to_excel(
        writer, sheet_name='Category Analysis', index=False)
    top5_prod.reset_index().rename(columns={'Net_Revenue':'Revenue'}).to_excel(
        writer, sheet_name='Top Products', index=False)
    salesperson.reset_index().to_excel(writer, sheet_name='Salesperson', index=False)
    pd.DataFrame({'KPI':['Total Revenue','Total Orders','Avg Order Value','Best Month','Top Region'],
                  'Value':[f'INR {total_rev:,.0f}', total_orders, f'INR {avg_order:,.0f}',
                           monthly.idxmax(), region_rev.idxmax()]}
    ).to_excel(writer, sheet_name='KPI Summary', index=False)
print("✅ Excel saved: sales_analysis_report.xlsx")
print("\n🎯 Project 1 Complete!")
