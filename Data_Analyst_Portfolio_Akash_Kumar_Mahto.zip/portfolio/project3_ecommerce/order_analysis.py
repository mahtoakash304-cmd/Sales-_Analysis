"""
PROJECT 3: E-Commerce Order & Delivery Analysis
By: Akash Kumar Mahto | Data Analyst Portfolio
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    'figure.facecolor': '#0A0F1C', 'axes.facecolor': '#111827',
    'axes.edgecolor': '#1E3A5F', 'text.color': '#E2E8F0',
    'axes.labelcolor': '#94A3B8', 'xtick.color': '#94A3B8',
    'ytick.color': '#94A3B8', 'grid.color': '#1E3A5F', 'grid.alpha': 0.5,
})
COLORS = ['#00D4AA','#FF6B6B','#FFD93D','#4D96FF','#C084FC','#6BCB77']

# ── Load & Clean ───────────────────────────────────────────────────────────────
df = pd.read_csv('ecommerce_orders.csv')

df.drop_duplicates(subset='Order_ID', inplace=True)
df['Order_Date']        = pd.to_datetime(df['Order_Date'])
df['Expected_Delivery'] = pd.to_datetime(df['Expected_Delivery'])
df['Actual_Delivery']   = pd.to_datetime(df['Actual_Delivery'])

# Remove logical errors
df = df[df['Actual_Delivery'] >= df['Order_Date']]
df = df[df['Expected_Delivery'] >= df['Order_Date']]

# Recalculate delay & status
df['Delay_Days'] = (df['Actual_Delivery'] - df['Expected_Delivery']).dt.days

def calc_status(row):
    if row['Delivery_Status'] == 'Returned': return 'Returned'
    return 'On-Time' if row['Delay_Days'] <= 0 else 'Late'

df['Delivery_Status'] = df.apply(calc_status, axis=1)
df['Month'] = df['Order_Date'].dt.strftime('%b')
df['Quarter'] = 'Q' + df['Order_Date'].dt.quarter.astype(str)
df.to_csv('ecommerce_clean.csv', index=False)

# ── Analysis ───────────────────────────────────────────────────────────────────
status_counts = df['Delivery_Status'].value_counts()
n = len(df)
on_time_rate  = status_counts.get('On-Time',0) / n * 100
late_rate     = status_counts.get('Late',0)    / n * 100
return_rate   = status_counts.get('Returned',0)/ n * 100
avg_delay     = df[df['Delivery_Status']=='Late']['Delay_Days'].mean()

state_analysis = df.groupby('State').agg(
    Total_Orders=('Order_ID','count'),
    Late_Orders=('Delivery_Status', lambda x: (x=='Late').sum()),
    Returned=('Delivery_Status',  lambda x: (x=='Returned').sum()),
    Total_Revenue=('Order_Amount','sum'),
    Avg_Order=('Order_Amount','mean')
).reset_index()
state_analysis['Late_Rate_Pct']   = (state_analysis['Late_Orders'] / state_analysis['Total_Orders'] * 100).round(1)
state_analysis['Return_Rate_Pct'] = (state_analysis['Returned']    / state_analysis['Total_Orders'] * 100).round(1)
state_analysis = state_analysis.sort_values('Late_Rate_Pct', ascending=False)

cat_analysis = df.groupby('Category').agg(
    Orders=('Order_ID','count'),
    Revenue=('Order_Amount','sum'),
    Returns=('Delivery_Status', lambda x: (x=='Returned').sum()),
    Late=('Delivery_Status',   lambda x: (x=='Late').sum())
).reset_index()
cat_analysis['Return_Rate_Pct'] = (cat_analysis['Returns'] / cat_analysis['Orders'] * 100).round(1)
cat_analysis = cat_analysis.sort_values('Revenue', ascending=False)

return_reasons = df[df['Delivery_Status']=='Returned']['Return_Reason'].value_counts()
return_reasons = return_reasons[return_reasons.index != 'NA']

payment_analysis = df.groupby('Payment_Mode').agg(
    Orders=('Order_ID','count'),
    Avg_Value=('Order_Amount','mean'),
    Returns=('Delivery_Status', lambda x: (x=='Returned').sum())
).reset_index()
payment_analysis['Return_Rate_Pct'] = (payment_analysis['Returns']/payment_analysis['Orders']*100).round(1)

print("=" * 60)
print("   PROJECT 3: E-COMMERCE ORDER & DELIVERY ANALYSIS")
print("=" * 60)
print(f"\n  Total Orders Analyzed  : {n:,}")
print(f"  ✅ On-Time Delivery    : {on_time_rate:.1f}%")
print(f"  ⏰ Late Delivery       : {late_rate:.1f}%")
print(f"  🔄 Return Rate         : {return_rate:.1f}%")
print(f"  📊 Avg Delay (Late)    : {avg_delay:.1f} days")
print(f"  💰 Total Revenue       : INR {df['Order_Amount'].sum():,.0f}")
print(f"  📦 Avg Order Value     : INR {df['Order_Amount'].mean():,.0f}")
print(f"\nStates with Highest Late Rate:")
for _, row in state_analysis.head(5).iterrows():
    print(f"  {row['State']:<20}: {row['Late_Rate_Pct']:.1f}% late | {row['Return_Rate_Pct']:.1f}% returned")
print(f"\nCategory Performance:")
for _, row in cat_analysis.iterrows():
    print(f"  {row['Category']:<18}: INR {row['Revenue']:>10,.0f} | Return Rate: {row['Return_Rate_Pct']:.1f}%")
print(f"\nTop Return Reasons:")
for reason, cnt in return_reasons.head(5).items():
    print(f"  {reason:<25}: {cnt} cases ({cnt/status_counts.get('Returned',1)*100:.1f}%)")
print(f"\nPayment Mode Analysis:")
for _, row in payment_analysis.sort_values('Avg_Value',ascending=False).iterrows():
    print(f"  {row['Payment_Mode']:<15}: {row['Orders']} orders | Avg: INR {row['Avg_Value']:,.0f}")
print("=" * 60)

# ── Charts ─────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12))
fig.suptitle('PROJECT 3: E-Commerce Delivery Analysis Dashboard\nAkash Kumar Mahto | Data Analyst Portfolio',
             fontsize=14, fontweight='bold', color='#FFD93D', y=0.98)

# Delivery Status
ax1 = fig.add_subplot(2, 3, 1)
labels = status_counts.index.tolist()
vals   = status_counts.values
status_colors = {'On-Time':'#00D4AA','Late':'#FF6B6B','Returned':'#FFD93D'}
pie_colors = [status_colors.get(l,'#4D96FF') for l in labels]
wedges, texts, autotexts = ax1.pie(vals, labels=labels, autopct='%1.1f%%',
    colors=pie_colors, pctdistance=0.75, wedgeprops=dict(width=0.55, edgecolor='#0A0F1C', linewidth=2))
for t in autotexts: t.set_fontsize(10); t.set_color('white'); t.set_fontweight('bold')
ax1.set_title('Delivery Status Overview', fontweight='bold')

# State Late Rate
ax2 = fig.add_subplot(2, 3, 2)
top_states = state_analysis.head(8)
bars2 = ax2.barh(top_states['State'][::-1], top_states['Late_Rate_Pct'][::-1],
                 color='#FF6B6B', alpha=0.85, height=0.6, zorder=3)
ax2.axvline(x=late_rate, color='#FFD93D', linestyle='--', linewidth=1.5, label=f'Avg {late_rate:.1f}%')
ax2.set_title('States: Highest Late Delivery Rate (%)', fontweight='bold')
ax2.set_xlabel('Late Rate (%)')
ax2.legend(fontsize=8)
ax2.grid(axis='x', zorder=0)

# Return Reasons
ax3 = fig.add_subplot(2, 3, 3)
ax3.bar(return_reasons.index, return_reasons.values, color=COLORS[:len(return_reasons)],
        alpha=0.85, width=0.6, zorder=3)
ax3.set_title('Return Reasons Breakdown', fontweight='bold')
ax3.set_ylabel('Number of Returns')
ax3.tick_params(axis='x', rotation=30)
ax3.grid(axis='y', zorder=0)

# Category Revenue
ax4 = fig.add_subplot(2, 3, 4)
ax4.barh(cat_analysis['Category'][::-1], cat_analysis['Revenue'][::-1]/1000,
         color=COLORS[1:], alpha=0.85, height=0.6, zorder=3)
ax4.set_title('Revenue by Category (INR 000s)', fontweight='bold')
ax4.set_xlabel('Revenue (INR 000s)')
ax4.grid(axis='x', zorder=0)

# Category Return Rate
ax5 = fig.add_subplot(2, 3, 5)
bars5 = ax5.bar(cat_analysis['Category'], cat_analysis['Return_Rate_Pct'],
                color='#C084FC', alpha=0.85, width=0.6, zorder=3)
ax5.axhline(y=return_rate, color='#FF6B6B', linestyle='--', label=f'Avg {return_rate:.1f}%')
ax5.set_title('Return Rate by Category (%)', fontweight='bold')
ax5.set_ylabel('Return Rate (%)')
ax5.tick_params(axis='x', rotation=30)
ax5.legend(fontsize=8)
ax5.grid(axis='y', zorder=0)

# Payment Mode
ax6 = fig.add_subplot(2, 3, 6)
pm = payment_analysis.sort_values('Orders', ascending=False)
ax6.bar(pm['Payment_Mode'], pm['Avg_Value'], color=COLORS[:len(pm)], alpha=0.85, width=0.5, zorder=3)
ax6.set_title('Avg Order Value by Payment Mode (INR)', fontweight='bold')
ax6.set_ylabel('Avg Order Value (INR)')
ax6.grid(axis='y', zorder=0)

plt.tight_layout(rect=[0,0,1,0.96])
plt.savefig('ecommerce_dashboard.png', dpi=150, bbox_inches='tight', facecolor='#0A0F1C', edgecolor='none')
plt.close()
print("\n✅ Chart saved: ecommerce_dashboard.png")

# ── Excel ──────────────────────────────────────────────────────────────────────
with pd.ExcelWriter('ecommerce_analysis_report.xlsx', engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Clean Data', index=False)
    state_analysis.to_excel(writer, sheet_name='State Analysis', index=False)
    cat_analysis.to_excel(writer, sheet_name='Category Analysis', index=False)
    payment_analysis.to_excel(writer, sheet_name='Payment Analysis', index=False)
    return_reasons.reset_index().rename(columns={'index':'Reason','Return_Reason':'Count'}).to_excel(
        writer, sheet_name='Return Reasons', index=False)
    pd.DataFrame({'KPI':['Total Orders','On-Time Rate','Late Rate','Return Rate','Avg Delay'],
                  'Value':[n, f'{on_time_rate:.1f}%', f'{late_rate:.1f}%',
                           f'{return_rate:.1f}%', f'{avg_delay:.1f} days']}
    ).to_excel(writer, sheet_name='KPI Summary', index=False)
print("✅ Excel saved: ecommerce_analysis_report.xlsx")
print("\n🎯 Project 3 Complete!")
