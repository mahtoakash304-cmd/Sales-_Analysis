"""
PROJECT 2: Customer Segmentation & RFM Analysis
By: Akash Kumar Mahto | Data Analyst Portfolio
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    'figure.facecolor': '#0A0F1C', 'axes.facecolor': '#111827',
    'axes.edgecolor': '#1E3A5F', 'text.color': '#E2E8F0',
    'axes.labelcolor': '#94A3B8', 'xtick.color': '#94A3B8',
    'ytick.color': '#94A3B8', 'grid.color': '#1E3A5F', 'grid.alpha': 0.5,
})
COLORS = ['#FF6B6B','#FFD93D','#00D4AA','#4D96FF','#C084FC']

# ── Load & Clean ───────────────────────────────────────────────────────────────
df = pd.read_csv('customer_data.csv')

df.drop_duplicates(subset='Customer_ID', inplace=True)
df['Last_Purchase_Date'] = pd.to_datetime(df['Last_Purchase_Date'])
df['Customer_Since']     = pd.to_datetime(df['Customer_Since'])
df = df[(df['Age'] >= 18) & (df['Age'] <= 70)]
df.dropna(subset=['Customer_ID','Total_Spent'], inplace=True)
df = df[df['Total_Spent'] > 0]
df = df[df['Total_Orders'] > 0]
df['Avg_Order_Value'] = (df['Total_Spent'] / df['Total_Orders']).round(2)

# ── RFM Calculation ────────────────────────────────────────────────────────────
today = pd.Timestamp('2025-01-01')
df['Recency']   = (today - df['Last_Purchase_Date']).dt.days
df['Frequency'] = df['Total_Orders']
df['Monetary']  = df['Total_Spent']

df['R_Score'] = pd.qcut(df['Recency'],   4, labels=[4,3,2,1]).astype(int)
df['F_Score'] = pd.qcut(df['Frequency'].rank(method='first'), 4, labels=[1,2,3,4]).astype(int)
df['M_Score'] = pd.qcut(df['Monetary'],  4, labels=[1,2,3,4]).astype(int)
df['RFM_Score'] = df['R_Score'] + df['F_Score'] + df['M_Score']

def segment(s):
    if s >= 10: return 'Champions'
    elif s >= 8: return 'Loyal'
    elif s >= 6: return 'Potential'
    elif s >= 4: return 'At Risk'
    else:        return 'Lost'

df['Segment'] = df['RFM_Score'].apply(segment)

# Age groups
df['Age_Group'] = pd.cut(df['Age'], bins=[17,25,35,45,55,70],
                          labels=['18-25','26-35','36-45','46-55','56+'])
df_clean = df.copy()
df_clean.to_csv('customer_clean.csv', index=False)

# ── Analysis ───────────────────────────────────────────────────────────────────
seg_order  = ['Champions','Loyal','Potential','At Risk','Lost']
seg_summary = df.groupby('Segment').agg(
    Count=('Customer_ID','count'),
    Avg_Spend=('Total_Spent','mean'),
    Total_Revenue=('Total_Spent','sum'),
    Avg_Orders=('Total_Orders','mean'),
    Avg_Recency=('Recency','mean')
).reindex(seg_order)
seg_summary['Revenue_Pct'] = (seg_summary['Total_Revenue'] / seg_summary['Total_Revenue'].sum() * 100).round(1)
seg_summary['Count_Pct']   = (seg_summary['Count'] / seg_summary['Count'].sum() * 100).round(1)

age_spend  = df.groupby('Age_Group')['Total_Spent'].mean()
city_rev   = df.groupby('City')['Total_Spent'].sum().nlargest(10)
gender_ana = df.groupby('Gender').agg(Count=('Customer_ID','count'), Avg_Spend=('Total_Spent','mean'))

print("=" * 60)
print("   PROJECT 2: CUSTOMER SEGMENTATION REPORT")
print("=" * 60)
print(f"\nTotal Customers Analyzed: {len(df)}")
print(f"\nCustomer Segment Breakdown:")
print(f"{'Segment':<14} {'Count':>6} {'Count%':>7} {'Avg Spend':>12} {'Revenue%':>9}")
print("-" * 55)
for seg, row in seg_summary.iterrows():
    print(f"{seg:<14} {row['Count']:>6.0f} {row['Count_Pct']:>6.1f}% INR {row['Avg_Spend']:>8,.0f} {row['Revenue_Pct']:>8.1f}%")

print(f"\nGender Analysis:")
for g, row in gender_ana.iterrows():
    print(f"  {g}: {row['Count']} customers | Avg Spend: INR {row['Avg_Spend']:,.0f}")

print(f"\nTop 5 Cities by Revenue:")
for i,(c,v) in enumerate(city_rev.head(5).items(), 1):
    print(f"  {i}. {c:<15}: INR {v:>10,.0f}")

print(f"\nAvg Spend by Age Group:")
for ag, v in age_spend.items():
    print(f"  {ag}: INR {v:,.0f}")
print("=" * 60)

# ── Charts ─────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12))
fig.suptitle('PROJECT 2: Customer Segmentation Dashboard\nAkash Kumar Mahto | Data Analyst Portfolio',
             fontsize=14, fontweight='bold', color='#FF6B6B', y=0.98)

# Segment Count
ax1 = fig.add_subplot(2, 3, 1)
counts = seg_summary['Count']
bars = ax1.bar(seg_order, counts, color=COLORS, alpha=0.85, width=0.6, zorder=3)
ax1.set_title('Customer Count by Segment', fontweight='bold')
ax1.set_ylabel('Number of Customers')
ax1.grid(axis='y', zorder=0)
ax1.tick_params(axis='x', rotation=25)
for bar, val in zip(bars, counts):
    ax1.text(bar.get_x()+bar.get_width()/2, bar.get_height()+2, str(int(val)),
             ha='center', fontsize=9, color='white', fontweight='bold')

# Revenue by Segment (Donut)
ax2 = fig.add_subplot(2, 3, 2)
rev_vals = seg_summary['Total_Revenue']
wedges, texts, autotexts = ax2.pie(rev_vals, labels=seg_order, autopct='%1.1f%%',
    colors=COLORS, pctdistance=0.78, wedgeprops=dict(width=0.55, edgecolor='#0A0F1C', linewidth=1.5))
for t in autotexts: t.set_fontsize(9); t.set_color('white')
ax2.set_title('Revenue Contribution by Segment', fontweight='bold')

# Avg Spend by Segment
ax3 = fig.add_subplot(2, 3, 3)
ax3.barh(seg_order[::-1], seg_summary['Avg_Spend'][::-1]/1000, color=COLORS[::-1], alpha=0.85, height=0.6, zorder=3)
ax3.set_title('Avg Customer Spend by Segment (INR 000s)', fontweight='bold')
ax3.set_xlabel('Avg Spend (INR 000s)')
ax3.grid(axis='x', zorder=0)

# Age Group
ax4 = fig.add_subplot(2, 3, 4)
age_cols = ['#FFD93D','#00D4AA','#FF6B6B','#4D96FF','#C084FC']
ax4.bar(age_spend.index, age_spend.values/1000, color=age_cols[:len(age_spend)], alpha=0.85, width=0.6, zorder=3)
ax4.set_title('Avg Spend by Age Group (INR 000s)', fontweight='bold')
ax4.set_ylabel('Avg Spend (INR 000s)')
ax4.grid(axis='y', zorder=0)

# Gender
ax5 = fig.add_subplot(2, 3, 5)
genders = gender_ana.index.tolist()
vals = gender_ana['Avg_Spend'].values
bars5 = ax5.bar(genders, vals/1000, color=['#4D96FF','#FF6B6B'], alpha=0.85, width=0.4, zorder=3)
ax5.set_title('Avg Spend by Gender (INR 000s)', fontweight='bold')
ax5.set_ylabel('Avg Spend (INR 000s)')
ax5.grid(axis='y', zorder=0)
for bar, val in zip(bars5, vals):
    ax5.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.1,
             f'INR {val/1000:.1f}K', ha='center', fontsize=9, color='white')

# Top Cities
ax6 = fig.add_subplot(2, 3, 6)
ax6.barh(city_rev.index[::-1], city_rev.values[::-1]/1000, color='#00D4AA', alpha=0.85, height=0.6, zorder=3)
ax6.set_title('Top 10 Cities by Total Revenue (INR 000s)', fontweight='bold')
ax6.set_xlabel('Revenue (INR 000s)')
ax6.grid(axis='x', zorder=0)

plt.tight_layout(rect=[0,0,1,0.96])
plt.savefig('customer_analysis.png', dpi=150, bbox_inches='tight', facecolor='#0A0F1C', edgecolor='none')
plt.close()
print("\n✅ Chart saved: customer_analysis.png")

# ── Excel ──────────────────────────────────────────────────────────────────────
with pd.ExcelWriter('customer_analysis_report.xlsx', engine='openpyxl') as writer:
    df_clean.to_excel(writer, sheet_name='Clean Data', index=False)
    seg_summary.reset_index().to_excel(writer, sheet_name='Segment Summary', index=False)
    age_spend.reset_index().to_excel(writer, sheet_name='Age Analysis', index=False)
    city_rev.reset_index().rename(columns={'Total_Spent':'Revenue'}).to_excel(writer, sheet_name='City Analysis', index=False)
    gender_ana.reset_index().to_excel(writer, sheet_name='Gender Analysis', index=False)
print("✅ Excel saved: customer_analysis_report.xlsx")
print("\n🎯 Project 2 Complete!")
