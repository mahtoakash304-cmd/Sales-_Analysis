# Data Analyst Portfolio - Akash Kumar Mahto
## BCA Final Year | JRSU Ranchi | 2025

---

## About This Portfolio
5 complete data analysis projects showcasing real-world skills in Python, Excel, and data visualization.
Designed for entry-level Data Analyst internship applications.

---

## Project Overview

| # | Project | Dataset | Key Tool | Output |
|---|---------|---------|----------|--------|
| 1 | Retail Sales Analysis | 800 rows | Python + Excel | sales_dashboard.png |
| 2 | Customer Segmentation (RFM) | 500 rows | Python + Excel | customer_analysis.png |
| 3 | E-Commerce Delivery Analysis | 1000 rows | Python + Excel | ecommerce_dashboard.png |
| 4 | Marketing Campaign ROI | 20 campaigns | Python + Excel | marketing_dashboard.png |
| 5 | Product Performance Scoring | 30 products | Python + Excel | product_dashboard.png |

---

## Folder Structure

```
portfolio/
├── project1_sales/
│   ├── retail_sales_data.csv        ← Raw dataset
│   ├── retail_sales_clean.csv       ← Cleaned dataset
│   ├── sales_analysis.py            ← Python source code
│   ├── sales_dashboard.png          ← Dashboard chart
│   └── sales_analysis_report.xlsx  ← Excel report (7 sheets)
│
├── project2_customers/
│   ├── customer_data.csv
│   ├── customer_clean.csv
│   ├── customer_analysis.py
│   ├── customer_analysis.png
│   └── customer_analysis_report.xlsx
│
├── project3_ecommerce/
│   ├── ecommerce_orders.csv
│   ├── ecommerce_clean.csv
│   ├── order_analysis.py
│   ├── ecommerce_dashboard.png
│   └── ecommerce_analysis_report.xlsx
│
├── project4_marketing/
│   ├── marketing_campaigns.csv
│   ├── marketing_clean.csv
│   ├── campaign_analysis.py
│   ├── marketing_dashboard.png
│   └── marketing_analysis_report.xlsx
│
└── project5_products/
    ├── product_performance.csv
    ├── product_clean.csv
    ├── product_analysis.py
    ├── product_dashboard.png
    └── product_analysis_report.xlsx
```

---

## How to Run

1. Install dependencies:
   ```
   pip install pandas matplotlib seaborn scikit-learn openpyxl
   ```

2. Navigate to any project folder and run the Python script:
   ```
   cd project1_sales
   python sales_analysis.py
   ```

---

## Key Skills Demonstrated

- **Data Cleaning**: Missing values, duplicates, type conversion, validation
- **Exploratory Analysis**: GroupBy, Pivot Tables, Aggregations
- **Statistics**: Mean, Sum, Correlation, Distribution
- **Segmentation**: RFM Analysis, Scoring Systems, Performance Scoring
- **Visualization**: Bar, Pie, Scatter, Histogram, Stacked Bar charts
- **Excel**: Multi-sheet reports with KPI summaries
- **Python Libraries**: pandas, matplotlib, seaborn, scikit-learn

---

## Key Insights Across Projects

1. **Sales**: North region leads (31.8%), Electronics = 36% of revenue
2. **Customers**: Top 23% (Champions) drive 41% of revenue — RFM proved
3. **E-Commerce**: UP/Bihar show 80%+ late rate — logistics red flag
4. **Marketing**: WhatsApp delivers 3017% ROI — highest with lowest budget
5. **Products**: Running Shoes tops performance score; Fashion has 12.7% return rate

---

## Contact
- **Name**: Akash Kumar Mahto
- **Education**: BCA, Jharkhand Raksha Shakti University, Ranchi
- **Skills**: Python, SQL, Excel, Power BI, Data Analysis
- **GitHub**: [Add your GitHub link here]
- **LinkedIn**: [Add your LinkedIn link here]

---
*Portfolio created for Data Analyst Internship Applications | 2025*
